package application;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

/**
 * Provides implementation for the home screen of the quiz generator
 * 
 * @author max
 *
 */
public class Main extends Application {
    Image image;

    @Override
    public void start(Stage primaryStage) {
        try {
            BorderPane root = new BorderPane();
            VBox vBox = new VBox(40);
            FileChooser file = new FileChooser();

            // label and xBox settings
            Label appName = new Label("Quiz Generator");
            appName.setFont(Font.font("Calabria", 32));
            vBox.setAlignment(Pos.CENTER);
            vBox.getChildren().add(appName);

            // create buttons
            Button createQ = new Button("Create Question");
            createQ.getStyleClass().add("create-question-button");
            Button loadJSON = new Button("Load JSON");
            loadJSON.getStyleClass().add("create-question-button");
            Button createQuiz = new Button("Create Quiz");
            createQuiz.getStyleClass().add("quiz-button");

            // add buttons to window
            vBox.getChildren().add(createQ);
            vBox.getChildren().add(loadJSON);
            vBox.getChildren().add(createQuiz);

            // question numbers
            Label questionNum = new Label("Total Number of Questions: ");
            questionNum.setFont(Font.font("Calabria", 20));
            vBox.getChildren().add(questionNum);

            // open json file action
            loadJSON.setOnAction(e -> {
                File jsonFile = file.showOpenDialog(primaryStage);
            });

            // open a new create question window
            createQ.setOnAction(e -> {

                VBox questionBox = questionCreation();
                Scene questionScene = new Scene(questionBox, 800, 600);
                Stage qWindow = new Stage();
                qWindow.setScene(questionScene);
                qWindow.setTitle("Create Question");
                qWindow.show();
            });

            // quiz creation
            createQuiz.setOnAction(e -> {
                Scene quizScene = quizConfigure();
                Stage qWindow = new Stage();
                qWindow.setScene(quizScene);
                qWindow.setTitle("Quiz create");
                qWindow.show();
            });

            // create and show windows
            Scene scene = new Scene(vBox, 800, 550);
            scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
            primaryStage.setScene(scene);
            primaryStage.setTitle("Quiz Generator");
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

    public VBox questionCreation() {
        VBox theVBox = new VBox();
        // Question Text
        Label questionTextLabel = new Label("Question Text:");
        TextField questionTextField = new TextField();
        theVBox.getChildren().addAll(questionTextLabel, questionTextField, new Label("\n\n"));
        // Question Topic
        HBox topicAndPictureHBox = new HBox();
        Label topicLabel = new Label("Question Topic:");
        TextField topicTextField = new TextField();

        // Image
        VBox filePathVBox = new VBox();
        HBox pictureHBox = new HBox();
        Label imageFilePathLabel = new Label("File path for the image:");
        TextField imageFilePathTextField = new TextField();
        Button loadImageButton = new Button("Load");
        try {
            image = new Image(new FileInputStream("src/images/noFile.png"));
        } catch (FileNotFoundException e3) {
            e3.printStackTrace();
        }
        HBox filePathAndButton = new HBox(imageFilePathTextField, loadImageButton);
        filePathVBox.getChildren().addAll(imageFilePathLabel, filePathAndButton);
        Region spacerRegion = new Region();
        HBox.setHgrow(spacerRegion, Priority.ALWAYS);
        pictureHBox.getChildren().addAll(filePathVBox, spacerRegion, new ImageView(image));
        // Add stuff to VBox
        topicAndPictureHBox.getChildren().addAll(new VBox(topicLabel, topicTextField), new Label("\t\t\t\t\t"),
                pictureHBox);
        theVBox.getChildren().add(topicAndPictureHBox);

        // Press Enter
        imageFilePathTextField.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ENTER) {
                pictureHBox.getChildren().remove(2);
                try {
                    image = new Image(new FileInputStream(imageFilePathTextField.getText()));
                } catch (FileNotFoundException e1) {
                    try {
                        image = new Image(new FileInputStream("src/images/fileNotFound.png"));
                    } catch (FileNotFoundException e2) {
                        e2.printStackTrace();
                    }
                }
                pictureHBox.getChildren().add(new ImageView(image));
            }
        });
        // Click "load" button
        loadImageButton.setOnAction(e -> {
            pictureHBox.getChildren().remove(2);
            try {
                image = new Image(new FileInputStream(imageFilePathTextField.getText()));
            } catch (FileNotFoundException e1) {
                try {
                    image = new Image(new FileInputStream("src/images/fileNotFound.png"));
                } catch (FileNotFoundException e2) {
                    e2.printStackTrace();
                }
            }
            pictureHBox.getChildren().add(new ImageView(image));
        });
        // Answers
        Label answerLabel = new Label("Answer Text:\t\t\t\t\t\t\t\t");
        Label checkBoxLabel = new Label("Correct Answer?");
        HBox labels = new HBox(answerLabel, checkBoxLabel);

        // Text fields for questions
        TextField q1Text = new TextField();
        q1Text.setPrefWidth(300);
        TextField q2Text = new TextField();
        q2Text.setPrefWidth(300);
        TextField q3Text = new TextField();
        q3Text.setPrefWidth(300);
        TextField q4Text = new TextField();
        q4Text.setPrefWidth(300);
        TextField q5Text = new TextField();
        q5Text.setPrefWidth(300);
        // Check Boxes
        CheckBox q1Box = new CheckBox();
        CheckBox q2Box = new CheckBox();
        CheckBox q3Box = new CheckBox();
        CheckBox q4Box = new CheckBox();
        CheckBox q5Box = new CheckBox();

        VBox answersVBox = new VBox(new HBox(q1Text, q1Box), new HBox(q2Text, q2Box), new HBox(q3Text, q3Box),
                new HBox(q4Text, q4Box), new HBox(q5Text, q5Box));
        theVBox.getChildren().addAll(new Label("\n\n\n\n\n\n\n\n"), labels, answersVBox);

        // Back and Finish Buttons
        Button backButton = new Button("Back");
        Button saveButton = new Button("Save Question");
        backButton.setOnAction(e -> {
            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.close();
            // Close window (returns to main menu)
        });
        saveButton.setOnAction(e -> {
            // TODO Make new Question Object

            // TODO Make new questionChoice Objects

            Stage stage = (Stage) saveButton.getScene().getWindow();
            stage.close();
            // Return to main menu by closing current window
        });
        Region reg1 = new Region();
        HBox.setHgrow(reg1, Priority.ALWAYS);
        HBox buttons = new HBox(backButton, reg1, saveButton);
        theVBox.getChildren().addAll(new Label("\n\n\n\n"), buttons);
        // Setup scene stuff
        return theVBox;
    }

    public VBox quizCreate() {
        try {
            // Label
            Label qPage = new Label("Insert Question Here");
            qPage.setFont(new Font("Arial", 32));

            // Image
            Image pic = new Image(new FileInputStream("src/images/fileNotFound.png"));
            ImageView imageView = new ImageView(pic);
            imageView.setFitHeight(200);
            imageView.setFitWidth(200);

            // Check and Home buttons
            Button Check = new Button("Check");
            Button Home = new Button("Home");
            Check.setMinSize(150, 75);
            Check.setFont(new Font("Arial", 28));
            Home.setMinSize(150, 75);
            Home.setFont(new Font("Arial", 28));

            // Multiple choice answer buttons
            RadioButton radio1, radio2, radio3, radio4, radio5;
            radio1 = new RadioButton("Answer 1");
            radio2 = new RadioButton("Answer 2");
            radio3 = new RadioButton("Answer 3");
            radio4 = new RadioButton("Answer 4");
            radio5 = new RadioButton("Answer 5");
            radio1.setFont(new Font("Arial", 20));
            radio2.setFont(new Font("Arial", 20));
            radio3.setFont(new Font("Arial", 20));
            radio4.setFont(new Font("Arial", 20));
            radio5.setFont(new Font("Arial", 20));

            // Only one at a time can be selected
            ToggleGroup question1 = new ToggleGroup();

            radio1.setToggleGroup(question1);
            radio2.setToggleGroup(question1);
            radio3.setToggleGroup(question1);
            radio4.setToggleGroup(question1);
            radio5.setToggleGroup(question1);

            // Only allows check after an answer is selected
            Check.setDisable(true);

            radio1.setOnAction(e -> Check.setDisable(false));
            radio2.setOnAction(e -> Check.setDisable(false));
            radio3.setOnAction(e -> Check.setDisable(false));
            radio4.setOnAction(e -> Check.setDisable(false));
            radio5.setOnAction(e -> Check.setDisable(false));

            VBox layout = new VBox();

            layout.getChildren().addAll(radio1, radio2, radio3, radio4, radio5);

            qPage.setWrapText(true);
            BorderPane root = new BorderPane();

            VBox v = new VBox();
            v.setMinHeight(600);
            v.setMinWidth(800);
            root.setMinHeight(600);
            root.setMinWidth(800);
            BorderPane footerFormat = new BorderPane();
            BorderPane headerFormat = new BorderPane();
            BorderPane ImageCenter = new BorderPane();
            v.getChildren().add(root);
            root.setTop(headerFormat);
            root.setLeft(layout);
            root.setBottom(footerFormat);
            footerFormat.setLeft(Home);
            footerFormat.setRight(Check);
            headerFormat.setCenter(qPage);
            headerFormat.setTop(ImageCenter);
            ImageCenter.setCenter(imageView);
            layout.setSpacing(10.0);
            return v;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Method to generate a scene with necessary components for the quiz
     * configuration It will have a text field for user to enter the numer of
     * questions for the quiz and a list of topic with checkbox for user to choose
     * topic for the quiz.
     * 
     * @return a scene that contains GUI components for quiz congifuration
     */
    public Scene quizConfigure() {
        // the Title on the top
        Label titleLabel = new Label("Quiz Generation");
        titleLabel.setFont(Font.font("Ariel", 30));

        // the 3 button on the bottom, back on the left, reset and confirm on the right
        Button backButton = new Button("Back");
        Button clearButton = new Button("Reset");
        Button confirmButton = new Button("Confirm");
        Region bottomRowPadding = new Region();
        HBox buttonRow = new HBox();
        buttonRow.getChildren().addAll(backButton, bottomRowPadding, clearButton, confirmButton);
        HBox.setHgrow(bottomRowPadding, Priority.ALWAYS);
        buttonRow.setSpacing(10);

        // Set confirm button to lead to quiz screen
        confirmButton.setOnAction(e -> {
            VBox quizBox = quizCreate();
            Scene quizViewScene = new Scene(quizBox, 800, 600);
            Stage qWindow = new Stage();
            qWindow.setScene(quizViewScene);
            qWindow.setTitle("Quiz display");
            qWindow.show();
        });

        // label and textfield for entering number of questions
        Label quesNumLabel = new Label("Please enter the number of question.");
        quesNumLabel.setFont(Font.font("Ariel", 15));
        TextField numOfQuestion = new TextField();
        VBox numQuestionDisplay = new VBox();
        numQuestionDisplay.getChildren().addAll(quesNumLabel, numOfQuestion);

        // label and Vbox used to display all the topic
        Label topicLabel = new Label("Select one or multiple topics for quiz's questions.");
        topicLabel.setFont(Font.font("Ariel", 20));
        VBox topicListDisplay = new VBox();
        VBox topicDisplay = new VBox();
        topicDisplay.getChildren().addAll(topicLabel, new Label(" "), topicListDisplay);
        // TODO during milestone 3 should replace this with a loop that add actual topic
        // from list
        topicListDisplay.getChildren().addAll(new HBox(new CheckBox(), new Label("hash table")),
                new HBox(new CheckBox(), new Label("linux")), new HBox(new CheckBox(), new Label("AVL tree")),
                new HBox(new CheckBox(), new Label("graph")));

        // set up borderpane and scene
        BorderPane root = new BorderPane();
        Scene scene = new Scene(root, 800, 450);
        root.setTop(titleLabel);
        BorderPane.setAlignment(titleLabel, Pos.CENTER);
        root.setLeft(topicDisplay);
        root.setBottom(buttonRow);
        root.setRight(numQuestionDisplay);

        return scene;
    }
}