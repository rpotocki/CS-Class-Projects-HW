# TeamProject (ateam89)

 - Team Members
	 - Ryan Potocki, LEC-001, xteam15
	 - Travis Bird, LEC-001, xteam38
	 - Colin Chen, LEC-004, xteam118
	 - Max Richter, LEC-002, xteam57
	 - Ojas Rade, LEC-001, xteam41
